function [daughtercell] = find_daughtercell(f,c)
% finds daughter cells of a specified cellid in contour file using overlap
% method and checking if area of daughter/mother looks correct. Ignores overlap less
% than 10%

imagesizex = 2000;
imagesizey = 2000;

if ~isfield(f,'cell')
    f.cell = f.cells;
end

if ~isfield(f.cells,'frame')
   for i = 1:numel(f.cells)
       f.cells(i).frame = f.cells(i).frames;
       f.object(i).frame = f.cells(i).bw_label;
   end
end

try
    fr = f.cell(c).frames;
    cid = f.cell(c).bw_label;
catch
    fr = f.cell(c).frame;
    cid = f.cell(c).object;
end

% daughtercell
xend = f.frame(fr(end)).object(cid(end)).Xcont;
yend = f.frame(fr(end)).object(cid(end)).Ycont;
targetcellmask_fordaughter = poly2mask(xend,yend,imagesizex,imagesizey);
linked_cid_fordaughter = [];
p_overlap_fordaughter = [];

    % for all cells after target cell
    
    potcells = get_potential_cells(f);
    
    for a = potcells
            frnew = f.cell(a).frame(f.cell(a).frame == fr(end)+1); %get mask of new cell
            cidnew = f.cell(a).object(f.cell(a).frame == fr(end)+1);
        if numel(frnew) > 1 %some cells have bad labelling. Using this to skip them
            daughtercell = [];
            return
        end
        if ~isempty(f.frame(frnew).object(cidnew).area)
            xdaughtercell = f.frame(frnew).object(cidnew).Xcont;
            ydaughtercell = f.frame(frnew).object(cidnew).Ycont;
            newcellmask_fordaughter = poly2mask(xdaughtercell,ydaughtercell,1002,1004);
            summatrix_fordaughter = targetcellmask_fordaughter + newcellmask_fordaughter;
            percent_overlap_fordaughter = numel(find(summatrix_fordaughter == 2))/numel(find(targetcellmask_fordaughter == 1));
            if percent_overlap_fordaughter > 0.1 && f.frame(frnew).object(cidnew).area < f.frame(fr(end)).object(cid(end)).area%if percent overlap
                %fprintf('cell %d with cell: %d overlap = %0.2f\n',c,a,percent_overlap)
                linked_cid_fordaughter = [linked_cid_fordaughter a]; % record cell
                p_overlap_fordaughter = [p_overlap_fordaughter percent_overlap_fordaughter];
            end
        end
    end
    
    %fprintf('number of overlapping cells = %d\n',numel(linked_cid))
    daughtercell = [];
    for j = 1:numel(linked_cid_fordaughter)
        c0 = find_mothercell(f,linked_cid_fordaughter(j));
        %fprintf('targetcell %d daughter cell %d, mother %d\n',c,linked_cid(j),c0)
        if c == c0
            daughtercell = [daughtercell linked_cid_fordaughter(j)];
        end
    end
end

function potcells = get_potential_cells(f) 
    idx = find(cellfun(@numel,{f.cells(1:end).object}) > 3);
    temp = cellfun(@(x) x(1),{f.cells(idx).frame},'UniformOutput',false);
    potcells = idx(find([temp{:}] == fr(end)+1));
end