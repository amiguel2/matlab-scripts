function [mothercell,daughtercell] = find_motherdaughtercell(f,c)
% finds daughter cells of a specified cellid in contour file using overlap
% method and checking if area of daughter/mother looks correct. Ignores overlap less
% than 10%

imagesizex = 2000;
imagesizey = 2000;

if ~isfield(f,'cell')
    f.cell = f.cells;
end

if ~isfield(f.cells,'frame')
    for i = 1:numel(f.cells)
        f.cells(i).frame = f.cells(i).frames;
        f.object(i).frame = f.cells(i).bw_label;
    end
end

fr = f.cell(c).frame;
cid = f.cell(c).object;


% mothercell
xstart = f.frame(fr(1)).object(cid(1)).Xcont; %get segmented image for target cell
ystart = f.frame(fr(1)).object(cid(1)).Ycont;
targetcellmask_formother = poly2mask(xstart,ystart,1002,1004);
p_overlap_formother = 0; % sets p_overlap
mothercell = [];

% daughtercell
xend = f.frame(fr(end)).object(cid(end)).Xcont;
yend = f.frame(fr(end)).object(cid(end)).Ycont;
targetcellmask_fordaughter = poly2mask(xend,yend,imagesizex,imagesizey);
linked_cid_fordaughter = [];
p_overlap_fordaughter = [];

    % for all cells with at least 3 frames
    idx = find(cellfun(@numel,{f.cells(1:end).object}) > 3);
    
    for a = idx
        % mother
        if ~isempty(f.frame(frnew_mother).object(cidnew_mother).area) && numel(f.cell(a).frame == fr(1)-1) == 1 %some cells have bad labelling. Using this to skip them
            frnew_mother = f.cell(a).frame(f.cell(a).frame == fr(1)-1);
            cidnew_mother = f.cell(a).object(f.cell(a).frame == fr(1)-1);
            
            %get segmented image for target cell
            xmothercell = f.frame(frnew_mother).object(cidnew_mother).Xcont;
            ymothercell = f.frame(frnew_mother).object(cidnew_mother).Ycont;
            newcellmask_formother = poly2mask(xmothercell,ymothercell,1002,1004);
            summatrix_formother = targetcellmask + newcellmask_formother; % add masks together
            percent_overlap_formother = numel(find(summatrix_formother == 2))/numel(find(targetcellmask == 1)); %find percentage of cells where matrix is additive
            if percent_overlap_formother > p_overlap_formother && percent_overlap_formother > 0.1 && f.frame(frnew_mother).object(cidnew_mother).area > f.frame(fr(1)).object(cid(1)).area % at least overlap greater than 10%
                mothercell = a; %record that cell
                p_overlap_formother = percent_overlap_formother;
            end
        end
        
        % daughter
        if (f.cell(a).frame(1) == fr(end)+1) && (numel(f.cell(a).frame == fr(end)+1) == 1) %some cells have bad labelling Using this to skip them
            frnew_daughter = f.cell(a).frame(1); %get mask of new cell
            cidnew_daughter = f.cell(a).object(1);
            if ~isempty(f.frame(frnew_daughter).object(cidnew_daughter).area)
                xdaughtercell = f.frame(frnew_daughter).object(cidnew_daughter).Xcont;
                ydaughtercell = f.frame(frnew_daughter).object(cidnew_daughter).Ycont;
                newcellmask_fordaughter = poly2mask(xdaughtercell,ydaughtercell,1002,1004);
                summatrix_fordaughter = targetcellmask_fordaughter + newcellmask_fordaughter;
                percent_overlap_fordaughter = numel(find(summatrix_fordaughter == 2))/numel(find(targetcellmask_fordaughter == 1));
                if percent_overlap_fordaughter > 0.1 && f.frame(frnew_daughter).object(cidnew_daughter).area < f.frame(fr(end)).object(cid(end)).area%if percent overlap
                    %fprintf('cell %d with cell: %d overlap = %0.2f\n',c,a,percent_overlap)
                    linked_cid_fordaughter = [linked_cid_fordaughter a]; % record cell
                    p_overlap_fordaughter = [p_overlap_fordaughter percent_overlap_fordaughter];
                end
            end
        else
            daughtercell = [];
        end
    end
    
    %fprintf('number of overlapping cells = %d\n',numel(linked_cid))
    daughtercell = [];
    if numel(linked_cid_fordaughter) == 2
        daughtercell = linked_cid_fordaughter;
    end
%     for j = 1:numel(linked_cid_fordaughter)
%         c0 = find_mothercell(f,linked_cid_fordaughter(j));
%         %fprintf('targetcell %d daughter cell %d, mother %d\n',c,linked_cid(j),c0)
%         if c == c0
%             daughtercell = [daughtercell linked_cid_fordaughter(j)];
%         end
%     end
end