
clear; close all;
cd('/Users/amiguel/Dropbox/Research/Projects/Rcs_System/RCS05 A22/A22 BW25112 titration/AM_IM33_deepcell/')
A22_0.list = dir('A22-0/*CONTOURS.mat'); % EM
A22_025.list = dir('A22-0.25/*CONTOURS.mat'); % WT
A22_050.list = dir('A22-0.5/*CONTOURS.mat'); % Peri
A22_075.list = dir('A22-0.75/*CONTOURS.mat'); % IM
A22_1.list = dir('A22-1/*CONTOURS.mat'); % IM
A22_2.list = dir('A22-2/*CONTOURS.mat'); % IM
A22_0.list

c1 = cbrewer('qual','Set1',6);
c2 = cbrewer('qual','Set2',6);
c = flipud([c1([1 5],:);c2(6,:);c1([6 3 2],:)]);
cd('A22-0');A22_0.cells = get_data(A22_0.list,1,0.0646,'onecolor',c(1,:),'tshift',11);cd('../')
cd('A22-0.25');A22_025.cells = get_data(A22_025.list,1,0.0646,'onecolor',c(2,:),'tshift',8);cd('../')
cd('A22-0.5');A22_050.cells = get_data(A22_050.list,1,0.0646,'onecolor',c(3,:),'tshift',6);cd('../')
cd('A22-0.75');A22_075.cells = get_data(A22_075.list,1,0.0646,'onecolor',c(4,:),'tshift',7);cd('../')
cd('A22-1');A22_1.cells = get_data(A22_1.list,1,0.0646,'onecolor',c(5,:),'tshift',6);cd('../')
cd('A22-2');A22_2.cells = get_data(A22_2.list,1,0.0646,'onecolor',c(6,:),'tshift',8);cd('../')

save('AM_IM33-getdata-fluor.mat')

%%
cs = A22_2;
for strn = extractfield(cs.list,'name')
 fprintf('%s\n',strn{:})
 x1 = find(cell2mat(cellfun(@(X) strcmp(X.contourfile,strn{:}),cs.cells,'UniformOutput',false))==1);
 plot_singlecell_data(cs.cells(x1),c(1,:),70,0,cbrewer('seq','Blues',76))
 pause;
end
%% Single Cell plots
exp = {A22_0.cells,A22_025.cells,A22_050.cells,A22_075.cells,filtdata(A22_1.cells),filtdata(A22_2.cells)};
expname = {'A22_0','A22_0p25','A22_0p5','A22_0p75','A22_1','A22_2'};
histc = {};
histc{1} = cbrewer('seq','Blues',76);
histc{2} = cbrewer('seq','Greens',76);
histc{3} = cbrewer('seq','YlGn',76);
histc{4} = cbrewer('seq','YlOrBr',76);
histc{5} = cbrewer('seq','Oranges',76);
histc{6} = cbrewer('seq','Reds',76);
for i = 5:5%6:numel(exp)
cs = exp{i};
figure('Color',[1 1 1]);
tF = 70;
tS = 0;
hc = histc{i};
hc = hc(12:end,:);
plot_singlecell_data(cs,c(i,:),tF,tS,hc)
fig = gcf;
fig.Position = [78 423 1026 500];
% prettifyplot([78 423 1026 275])
% saveplots(plotsave)
f1 = unsubplot(2,3,1,fig); prettifyplot; saveplots([expname{i} '-length']);
f2 = unsubplot(2,3,2,fig); prettifyplot; saveplots([expname{i} '-width']);
f3 = unsubplot(2,3,3,fig); colormap(hc); prettifyplot; saveplots([expname{i} '-gr']);
f4 = unsubplot(2,3,4,fig); prettifyplot; saveplots([expname{i} '-flr']);
f5 = unsubplot(2,3,5,fig); prettifyplot; saveplots([expname{i} '-wvflr']);

end

%% Median Comparisons
% exp = {A22_0.filtcells,A22_025.cells,A22_050.cells,A22_075.cells,A22_1.cells,A22_2.cells};
% expname = {'A22_0','A22_0p25','A22_0p5','A22_0p75','A22_1','A22_2'};
tS = 0;
tF = 70;
lineage_on = 0; 
fluor_on = 1;
mediandata = plot_median_data(exp,expname,tS,tF,lineage_on,fluor_on);
%%
fig = gcf;
%f1 = unsubplot(2,3,1,fig); ylim([2 7]); prettifyplot; saveplots('am33-length');
%f2 = unsubplot(2,3,2,fig); prettifyplot; saveplots('am33-width');
%f3 = unsubplot(2,3,3,fig); prettifyplot; saveplots('am33-gr');
f4 = unsubplot(2,3,4,fig); prettifyplot; saveplots('am33-fluor');
%f5 = unsubplot(2,3,6,fig); xlim([1.2 2]);prettifyplot; saveplots('am33-flvw');






%%

cs = A22_2.cells;
idx = find(cell2mat(cellfun(@(X) X.startt > 20,cs,'UniformOutput',false))==1);

for i = idx
   c = cs{i};
   subplot(1,2,1)
   yyaxis left; plot(smooth(c.width));
%    ylim([1.1 2])
   yyaxis right; plot(smooth(c.avg_fluor));
   subplot(1,2,2)
   yyaxis left; plot(c.instant_lambda_w); 
   yyaxis right; plot(c.instant_lambda_fluor);
   pause;
    
end






