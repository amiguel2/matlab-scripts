function [cids,vargout] = get_cids(data,varargin)
    if numel(varargin) > 0
        cf = varargin{1};
        cids = cellfun(@(x) getfield(x,'cid'),data);
        cfiles =  cellfun(@(x) getfield(x,'contourfile'),data,'UniformOutput',false);
        idx = find(strcmp(cfiles,cf));
        cids = cids(idx);
    else
        cids = cellfun(@(x) getfield(x,'cid'),data);
        vargout{1} =  cellfun(@(x) getfield(x,'contourfile'),data,'UniformOutput',false);
    end
end