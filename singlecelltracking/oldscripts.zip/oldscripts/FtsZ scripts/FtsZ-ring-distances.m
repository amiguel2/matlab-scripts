%% folders and lists
clear;
%ph_image_folder='/Users/amiguel/CloudStation/Imaging/14-10-04/phase';
%gfp_image_folder='/Users/amiguel/CloudStation/Imaging/14-10-04/GFP';
ph_image_folder='/Users/amiguel/CloudStation/Imaging/14-04-16/BW25113_ceph_35ugml_Phase_100ms_GFP_35ms_ND_1_1/stacks/';
gfp_image_folder='/Users/amiguel/CloudStation/Imaging/14-04-16/BW25113_ceph_35ugml_Phase_100ms_GFP_35ms_ND_1_1/stacks/';
script_folder='/Users/amiguel/Documents/MATLAB/matlab_scripts/analysis/FtsZ';
cd(script_folder)
prefix='/*eri-';
list = dir([gfp_image_folder,prefix,'*.mat']);
list_gfp = dir([gfp_image_folder,prefix,'*GFP.tif']);
list_phase = dir([ph_image_folder,prefix,'*Phase.tif']);

%% calculate the meshing
for i = 1:numel(list)
    f = load([gfp_image_folder,'/',list(i).name]);
    if isfield(f.frame(1).object,'mesh') == 0
        for j = 1:numel(f.frame.object)
           fprintf('Meshing: %s\n',list(i).name);
           [m,l,w] = calculate_mesh(f.frame.object(j));
           f.frame.object(j).mes%h = m;
           f.frame.object(j).lengt%h = l;
           f.frame.object(j).widt%h = w;
           save([gfp_image_folder,'/',list(i).name],'-struct','f');
        end
    end
end

%% calculate the meshing (timelapse)
for i = 1:numel(list)
    f = load([gfp_image_folder,'/',list(i).name]);
    if isfield(f.frame(1).object,'mesh') == 0
        for j = 1:numel(f.frame)
           if f.frame(j).num_cells > 0
               for k = 1:numel(f.frame(j).object)
                   %if f.frame(j).object(k).
                   fprintf('Meshing: %s\n',list(i).name);
                   [m,l,w] = calculate_mesh(f.frame(j).object(k));
                   f.frame(j).object(k).mes%h = m;
                   f.frame(j).object(k).lengt%h = l;
                   f.frame(j).object(k).widt%h = w;
               end
           end
        end
        save([gfp_image_folder,'/',list(i).name],'-struct','f');
    end
end

%% calculate fluorescence
for j=1:numel(list)
    im_idx = get_image_index_from_contour(list(j).name,list_gfp,'_phase_15-Oct-2014_CONTOURS.mat','_GFP.tif');
    contourfile = [gfp_image_folder,'/',list(j).name];
    s = load(contourfile);
    if isfield(s.frame(1).object,'ave_fluor')
        fprintf('Already exists\n')
    elseif isnan(im_idx)
        fprintf('No GFP image\n')
        
        pause
    else
        calculate_fluor_profiles([gfp_image_folder,'/',list(j).name],[gfp_image_folder,'/',list_gfp(im_idx).name],'',[],[gfp_image_folder,'/']);
    end
end

%%



%% Iterate through cells and identify FtsZ rings to measure
%if exist(memory)
%mem_num = length(memory)+1
%end

memory = struct('filename',[],'cell',[],'added',[],'dist',[])
mem_num = 1;
dist = [];

for a = 1:1
    fr = a;
    for i =1:numel(list)
        fprintf('%s\n',list(i).name)
        % Retrive the correct image folder with the contour file. 
        contourfile = [gfp_image_folder,'/',list(i).name];
        im_idx = get_image_index_from_contour(list(i).name,list_gfp,'_CONTOURS.mat','_GFP.tif');
        im_idx_phase = get_image_index_from_contour(list(i).name,list_phase,'_CONTOURS.mat','_Phase.tif');
%         im_idx = get_image_index_from_contour(list(i).name,list_gfp,'_phase_13-Oct-2014_CONTOURS.mat','_GFP.tif');
%         if isnan(im_idx)
%             im_idx = get_image_index_from_contour(list(i).name,list_gfp,'_phase_15-Oct-2014_CONTOURS.mat','_GFP.tif');
%         end
%         im_idx_phase = get_image_index_from_contour(list(i).name,list_phase,'_phase_13-Oct-2014_CONTOURS.mat','_phase.tif');
%         if isnan(im_idx_phase)
%             im_idx_phase = get_image_index_from_contour(list(i).name,list_phase,'_phase_15-Oct-2014_CONTOURS.mat','_phase.tif');
%         end
        if isnan(im_idx) || isnan(im_idx_phase)
        else
        imagefile = [gfp_image_folder,'/',list_gfp(im_idx).name];
        imagefile_phase=[ph_image_folder,'/',list_phase(im_idx_phase).name];
        cont = load(contourfile);
        
        % find filtered cells and retrieve corresponding cell id in contour frame
        [frame,cellid] = extract_filtered_cells(contourfile);
        cell_list = cellid(find(frame == fr));
        
        %Go through the cells 
        for j = 1:length(cell_list)
            % check if analyzed already
            cont_names = extractfield(memory,'filename');
            cell_names = extractfield(memory,'cell');
            cont_indx = find(strcmp(list(i).name,cont_names));
            if isempty(find(cell_list(j) == cell_names(cont_indx)))
                %retrieve correct contour data
                fluor_profile = contour_fluor_cell(contourfile,cell_list(j),fr);
                % Use half the data`
                fluor_profile = fluor_profile(1:end/2);
                % Find the peaks within the fluorescence data, retrieving the
                % x,y coordinates of the top of the peak
                if length(fluor_profile) > 45
                    %[y,x]=findpeaks(smooth(fluor_profile,5),'minpeakdistance',20,'minpeakprominence',700);
                    [y,x]=findpeaks(smooth(fluor_profile,5),'minpeakdistance',20,'minpeakprominence',700);
                    % find the indexes of those peaks that ignore the first and last 5% of the
                    % data
                    idx = find(x > .05*length(fluor_profile) & x < .95*length(fluor_profile));
                    % get the cell id field for all the
                    cids = extractfield(cont.frame(fr).object, 'cellID');
                    % find the index where object matches cell id
                    cell_object_indx = find(cids == cell_list(j));
                    
                    % if there is only 1 peak
                    if length(idx) == 2
                        figure(1)
                        %subplot(2,1,1)
                        %plot(fluor_profile)
                        hold on;
                        %scatter(x,y)
                        ring_distance = sum(sqrt(diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[1,3]),2)).^2+diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[2,4]),2)).^2));
                        %plot([x(idx(1)),x(idx(2))],[y(idx(2)),y(idx(2))],'red')
                        hold off;
                        %subplot(2,2,3)
                        %plotSingleCell_image_frame(imagefile,contourfile,cell_list(j),fr)
                        hold on;
                        %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[2,4]),2),'g')
                        hold off;
                        %pause;
                        %subplot(2,2,4)
                        %plotSingleCell_image_frame(imagefile_phase,contourfile,cell_list(j),fr)
                        hold on;
                        %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[2,4]),2),'g')
                        hold off;
                        %h = figure(2);;
                        %plotSingleCell_image_entireframe(imagefile,contourfile,cell_list(j),fr)
                        hold on;
                        %%plot(cont.frame(fr).object(cell_object_indx).Xcont(x(idx(1)):x(idx(2))),cont.frame(fr).object(cell_object_indx).Ycont(x(idx(1)):x(idx(2))))
                        %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[2,4]),2),'g')
                        hold off;
                        %imdistline
                        figure(1)
                        fprintf('%s: Cell %d\n',list(i).name,cell_list(j))
                        response1 = 'y';
                        %response1 = input('Analyze this cell? Y/N','s');
                        if response1 == 'y'
                            fprintf('Added: %3.2f\n', ring_distance)
                            dist = [dist ring_distance];
                            memory(mem_num) = struct('filename',list(i).name,'cell',cell_list(j),'added','y','dist',ring_distance);
                            mem_num = mem_num + 1;
                        else
                            memory(mem_num) = struct('filename',list(i).name,'cell',cell_list(j),'added','n','dist',[]);
                            mem_num = mem_num + 1;
                        end
                        
                        % if there is more than 1 peak
                    elseif length(idx) >2
                        figure(1)
                        %p_hist = subplot(2,1,1);
                        %plot(fluor_profile)
                        hold on;
                        %scatter(x,y)
                        hold off;
                        %p_gfp = subplot(2,2,3);
                        %plotSingleCell_image_frame(imagefile,contourfile,cell_list(j),fr)
                        hold on;
                        %%plot(cont.frame(fr).object(cell_object_indx).Xcont(x(idx(1)):x(idx(2))),cont.frame(fr).object(cell_object_indx).Ycont(x(idx(1)):x(idx(2))))
                        %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[2,4]),2),'g')
                        hold off;
                        %p_phase = subplot(2,2,4);
                        %plotSingleCell_image_frame(imagefile_phase,contourfile,cell_list(j),fr)
                        hold on;

                        %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[2,4]),2),'g')
                        hold off;
                        num = 1;
                        k_o = 1;
                        %h = figure(2);
                        %plotSingleCell_image_entireframe(imagefile,contourfile,cell_list(j),fr)
                        hold on;

                        %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[2,4]),2),'g')
                        hold off;
                        %imdistline
                        figure(1)
                        response = 'y';
                        fprintf('%s: Cell %d\n',list(i).name,cell_list(j))
                        %response = input('Analyze this cell? Y/N','s');
                        if response == 'y'
                            for k = 1:length(idx)-1
                                num = 1;
                                if k < k_o
                                    display('Skipped peak')
                                else
                                    ring_distance = sum(sqrt(diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2)).^2+diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2)).^2));
                                    while ring_distance < 30 && num+k < length(idx)
                                        num = num +1;
                                        %ring_distance = abs(x(idx(k))-x(idx(k+num)));
                                        ring_distance = sum(sqrt(diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2)).^2+diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2)).^2));
                                    end
                                    if ring_distance > 30 && num+k
                                        figure(1)
                                        %p_hist = subplot(2,1,1)
                                        %plot(fluor_profile)
                                        hold on;
                                        %scatter(x,y)
                                        %scatter(x(idx(k)),y(idx(k)),'red')
                                        %scatter(x(idx(k+num)),y(idx(k+num)),'red')
                                        %plot([x(idx(k)),x(idx(k+num))],[y(idx(k+num)),y(idx(k+num))],'red')
                                        %text(x(idx(k+num)),y(idx(k+num)),[num2str(ring_distance),' pixels'])
                                        hold off;
                                        %display(ring_distance)
                                        %p_gfp = subplot(2,2,3)
                                        %plotSingleCell_image_frame(imagefile,contourfile,cell_list(j),fr)
                                        hold on;%plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2),'g')
                                        hold off;
                                        %p_phase = subplot(2,2,4)
                                        %plotSingleCell_image_frame(imagefile_phase,contourfile,cell_list(j),fr)
                                        hold on;%plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2),'g')
                                        hold off;
                                        %h = figure(2);
                                        %plotSingleCell_image_entireframe(imagefile,contourfile,cell_list(j),fr)
                                        hold on;
                                        %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2),'g')
                                        hold off;
                                        %imdistline
                                        figure(1)
                                        result='y';
                                        %result = input('1. Add to distribution? Y/M/N','s');
                                        if result == 'y'
                                            k_o = num+k;
                                            num = 1;
                                            fprintf('Added: %3.2f\n', ring_distance)
                                            dist = [dist ring_distance];
                                            memory(mem_num) = struct('filename',list(i).name,'cell',cell_list(j),'added','y','dist',ring_distance);
                                            mem_num = mem_num + 1;
                                        elseif result == 'm'
                                            while result ~= 'y' && num+k < length(idx)
                                                num = num +1;
                                                figure(1)
                                                %p_hist = subplot(2,1,1)
                                                %plot(fluor_profile)
                                                hold on;
                                                %scatter(x,y)
                                                %scatter(x(idx(k+num)),y(idx(k+num)),'green')
                                                %plot([x(idx(k)),x(idx(k+num))],[y(idx(k+num)),y(idx(k+num))],'green')
                                                ring_distance = sum(sqrt(diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2)).^2+diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2)).^2));
                                                %text(x(idx(k+num)),y(idx(k+num)),[num2str(ring_distance),' pixels'])
                                                hold off;
                                                %p_gfp = subplot(2,2,3)
                                                %plotSingleCell_image_frame(imagefile,contourfile,cell_list(j),fr)
                                                hold on;
                                                %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2),'g')
                                                hold off;
                                                %p_phase = subplot(2,2,4)
                                                %plotSingleCell_image_frame(imagefile_phase,contourfile,cell_list(j),fr)
                                                hold on;
                                                %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2),'g')
                                                hold off;
                                                %h = figure(2);
                                                %plotSingleCell_image_entireframe(imagefile,contourfile,cell_list(j),fr)
                                                hold on;
                                                %plot(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2),mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2),'g')
                                                hold off;
                                                %imdistline
                                                figure(1)
                                                
                                                %display(ring_distance)
                                                result = input('2. Add to distribution?','s');
                                            end
                                            if result == 'y'
                                                k_o = num+k;
                                                num = 1;
                                                fprintf('Added: %3.2f\n', ring_distance)
                                                dist = [dist ring_distance];
                                                memory(mem_num) = struct('filename',list(i).name,'cell',cell_list(j),'added','y','dist',ring_distance);
                                                mem_num = mem_num + 1;
                                                
                                            elseif result ~= 'y'
                                                k_o = k;
                                                num=1;
                                                memory(mem_num) = struct('filename',list(i).name,'cell',cell_list(j),'added','n','dist',[]);
                                                mem_num = mem_num + 1;
                                            end
                                        else
                                            k_o = k;
                                            num=1;
                                            memory(mem_num) = struct('filename',list(i).name,'cell',cell_list(j),'added','n','dist',[]);
                                            mem_num = mem_num + 1;
                                        end
                                    else
                                        fprintf('Did not pass %d',ring_distance)
                                    end
                                end
                            end
                        else
                            memory(mem_num) = struct('filename',list(i).name,'cell',cell_list(j),'added','n','dist',[]);
                            mem_num = mem_num + 1;
                        end
                    end
                end
            end
                hold off;
            end
        end
    end
end