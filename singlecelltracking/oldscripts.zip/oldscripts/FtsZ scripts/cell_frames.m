
function cf = cell_frames(frame)
% Extracts the highest cellID value in the last frame
max_id = 0;
for i=1:length(frame)
    if ~isempty(frame(i).object)
        id = max(extractfield(frame(i).object,'cellID'));
        max_id = max(id,max_id);
    end
end

nc = max_id;
%nc = max(extractfield(frame(length(frame)).object, 'cellID'));
% creates the cell with that value
cf = cell([nc,1]);

for i = 1:length(frame)
   for j = 1:length(frame(i).object)
       cellid = frame(i).object(j).cellID;
       %fprintf('%d,%d,%d\n',i,j,cellid)
       if ~isempty(cellid)
           % with index function as cellid number, appends the current frame to
           % existing cell contents
           cf{cellid} = [cf{cellid} i];
       end
   end
end
end