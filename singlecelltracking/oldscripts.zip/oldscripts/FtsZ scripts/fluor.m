% read in frame n from tiffstack
for q=[0 1 3 5]
    fname = ['GFP0',int2str(q),'.tif'];
    info = imfinfo(fname);
    num_images = numel(info);
    
    contfile = ['Pos0',int2str(q),'_CONTOURS.mat'];
    load(contfile);
    fprintf('Loading %s...\n',contfile);
    % loop over all frames
    for i=1:2:numel(frame)
        
        k = (i+1)/2;
        im = imread(fname, k, 'Info', info);
        
        for j=1:numel(frame(i).object)
            data = frame(i).object(j);
            
            if numel(data.area)>0
                fprintf('Processing frame %d, object %d...\n',i,j);
                xs = data.Xcont;
                ys = data.Ycont;
                
                dist_in = 5;
                dist_out = 5;
                N = 10;
                fl = contour_signal(im,xs,ys,dist_in,dist_out,N);
                
                frame(i).object(j).fluor_profile = fl;
            end
        end
    end
    
    clear im dist_in dist_out xs ys N fl q fname info num_images;
    
    save(contfile);
end
