
% creates cell object from a frame
function [m,time] = contour_fluor_cell_time(contourfile,cellID,curv_thresh)

f = load(contourfile);
[frame,cellid] = extract_filtered_cells(contourfile,curv_thresh);
cf = frame(find(cellID == cellid));
time = [];
x = 0;
for i = 1:length(cf)
    ids = extractfield(f.frame(cf(i)).object,'cellID');
    idx = find(ids == cellID);
    x = max(x,length(f.frame(cf(i)).object(idx).fluor_profile));
end
m = zeros(length(cf),x);

for i = 1:length(cf)
    ids = extractfield(f.frame(cf(i)).object,'cellID');
    idx = find(ids == cellID);
    fp = f.frame(cf(i)).object(idx).fluor_profile;
    a = round((x-length(fp))/2);
    
    fp_temp = padarray(fp,[a,0],0,'post');
    m(i,:) = padarray(fp_temp,[x-length(fp)-a,0],0,'pre');
    time = [time cf(i)];
end
end