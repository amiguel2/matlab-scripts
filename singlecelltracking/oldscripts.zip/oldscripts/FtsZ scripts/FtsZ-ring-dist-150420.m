%% folders and lists
clear;
%ph_image_folder='/Users/amiguel/CloudStation/Imaging/14-10-04/phase';
%gfp_image_folder='/Users/amiguel/CloudStation/Imaging/14-10-04/GFP';
ph_image_folder='/Users/amiguel/Documents/Research/Projects/RcsF mutant/FtsZ rcsF/FtsZ imaging/15-03-05_FtsZ_sfGFP_all_strains_ceph35ugml/stacks';
gfp_image_folder='/Users/amiguel/Documents/Research/Projects/RcsF mutant/FtsZ rcsF/FtsZ imaging/15-03-05_FtsZ_sfGFP_all_strains_ceph35ugml/stacks/GFP';
cont_folder='/Users/amiguel/Documents/Research/Projects/RcsF mutant/FtsZ rcsF/FtsZ imaging/15-03-05_FtsZ_sfGFP_all_strains_ceph35ugml/stacks/Contours';
script_folder='/Users/amiguel/Documents/Research/Projects/RcsF mutant/FtsZ rcsF/FtsZ scripts';
cd(script_folder)
prefix='/3*';
list = dir([cont_folder,prefix,'*.mat']);
list_gfp = dir([gfp_image_folder,prefix,'*GFP.tif']);
list_phase = dir([ph_image_folder,prefix,'*.tif']);

%% calculate the meshing
for i = 1:numel(list)
    f = load([gfp_image_folder,'/',list(i).name]);
    if isfield(f.frame(1).object,'mesh') == 0
        for j = 1:numel(f.frame.object)
           fprintf('Meshing: %s\n',list(i).name);
           [m,l,w] = calculate_mesh(f.frame.object(j));
           f.frame.object(j).mes%h = m;
           f.frame.object(j).lengt%h = l;
           f.frame.object(j).widt%h = w;
           save([gfp_image_folder,'/',list(i).name],'-struct','f');
        end
    end
end

%% calculate the meshing (timelapse)
for i = 1:numel(list)
    f = load([gfp_image_folder,'/',list(i).name]);
    if isfield(f.frame(1).object,'mesh') == 0
        for j = 1:numel(f.frame)
           if f.frame(j).num_objs > 0
               for k = 1:numel(f.frame(j).object)
                   %if f.frame(j).object(k).
                   fprintf('Meshing: %s\n',list(i).name);
                   [m,l,w] = calculate_mesh(f.frame(j).object(k));
                   f.frame(j).object(k).mesh = m;
                   f.frame(j).object(k).length = l;
                   f.frame(j).object(k).width = w;
               end
           end
        end
        save([gfp_image_folder,'/',list(i).name],'-struct','f');
    end
end

%% calculate fluorescence
for j=1:numel(list)
    im_idx = get_image_index_from_contour(list(j).name,list_gfp,'_19-Apr-2015_CONTOURS.mat','_GFP.tif');
    contourfile = [gfp_image_folder,'/',list(j).name];
    s = load(contourfile);
    if isfield(s.frame(1).object,'ave_fluor')
        fprintf('Already exists\n')
    elseif isnan(im_idx)
        fprintf('No GFP image\n')
        
        pause
    else
        calculate_fluor_profiles([gfp_image_folder,'/',list(j).name],[gfp_image_folder,'/',list_gfp(im_idx).name],'',[],[gfp_image_folder,'/']);
    end
end

%%
cont_folder='/Users/amiguel/Documents/Research/Projects/RcsF mutant/FtsZ rcsF/FtsZ imaging/15-03-05_FtsZ_sfGFP_all_strains_ceph35ugml/stacks/Contours';
prefix='/3*';
sublist = dir([cont_folder,prefix,'*.mat']);
pxl = 0.064;
curv_thresh = -1:0.1:0;
%l_thresh = 0
%w_thresh = 
curv_count = NaN(1,length(curv_thresh));
for a = 1:length(curv_thresh)
    count = 0;
    for i = 1:numel(sublist)
        f = load([cont_folder '/' sublist(i).name]);
        [frame,cellid] = extract_filtered_cells([cont_folder '/' sublist(i).name]);
        for j = 1:max(cellid)
            f_list = frame(find(j == cellid));
            len_list = []; 
            wid_list = [];
            t_list = [];
            for k = f_list
                idx = find(j == extractfield(f.frame(k).object,'cellID'));
                if f.frame(k).object(idx).kappa_smooth > curv_thresh(a)
                    count = count + 1;
                    len_list= [len_list f.frame(k).object(idx).length];
                    wid_list=[wid_list f.frame(k).object(idx).width];
                    t_list = [t_list k];
                end
            end
        end
    end
    curv_count(a) = count;
end
%sprintf('Count: %d',count)
bar(curv_thresh,curv_count)

%% Iterate through cells and identify FtsZ rings to measure
%if exist(memory)
%mem_num = length(memory)+1
%end

cont_folder='/Users/amiguel/Documents/Research/Projects/Nassos Typas RcsF FtsZ MreB/FtsZ rcsF/FtsZ imaging/15-03-05_FtsZ_sfGFP_all_strains_ceph35ugml/stacks/Contours';
script_folder='/Users/amiguel/Documents/Research/Projects/Nassos Typas RcsF FtsZ MreB/FtsZ rcsF/FtsZ scripts';
cd(script_folder)
prefix={'/3*','/4*','/5*','/6*'};
curv_thresh = -0.3;
mem_var_name = {'mem1','mem2','mem3','mem4'}
for z = 1:length(prefix)
    list = dir([cont_folder,prefix{z},'*.mat']);
    memory = struct('filename',[],'frame',[],'cell',[],'added',[],'dist',[]);
    mem_num = 1;
    dist = [];
    
    for a = 1:9
        fr = a;
        for i =1:numel(list)
            %fprintf('%s\n',list(i).name)
            contourfile = [cont_folder,'/',list(i).name];
            cont = load(contourfile);
            
            % find filtered cells and retrieve corresponding cell id in contour frame
            [frame,cellid] = extract_filtered_cells(contourfile,curv_thresh);
            cell_list = cellid(find(frame == fr));
            
            %Go through the cells
            for j = 1:length(cell_list)
                % check if analyzed already
                cont_names = extractfield(memory,'filename');
                cell_names = extractfield(memory,'cell');
                cont_indx = find(strcmp(list(i).name,cont_names));
                if isempty(find(cell_list(j) == cell_names(cont_indx)))
                    %retrieve correct contour data
                    fluor_profile = contour_fluor_cell(contourfile,cell_list(j),fr);
                    % Use half the data`
                    fluor_profile = fluor_profile(1:end/2);
                    % Find the peaks within the fluorescence data, retrieving the
                    % x,y coordinates of the top of the peak
                    if length(fluor_profile) > 45
                        [y,x]=findpeaks(smooth(fluor_profile,5),'minpeakdistance',20,'minpeakprominence',700);
                        % find the indexes of those peaks that ignore the first and last 5% of the
                        % data
                        idx = find(x > .05*length(fluor_profile) & x < .95*length(fluor_profile));
                        % get the cell id field for all the
                        cids = extractfield(cont.frame(fr).object, 'cellID');
                        % find the index where object matches cell id
                        cell_object_indx = find(cids == cell_list(j));
                        
                        % if there is only 1 peak
                        if length(idx) == 2
                            ring_distance = sum(sqrt(diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[1,3]),2)).^2+diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(1))*2:x(idx(2))*2,[2,4]),2)).^2));
                            %fprintf('%s: Cell %d\n',list(i).name,cell_list(j))
                            response1 = 'y';
                            %response1 = input('Analyze this cell? Y/N','s');
                            if response1 == 'y'
                                %fprintf('Added: %3.2f\n', ring_distance)
                                dist = [dist ring_distance];
                                memory(mem_num) = struct('filename',list(i).name,'frame',fr,'cell',cell_list(j),'added','y','dist',ring_distance);
                                mem_num = mem_num + 1;
                            else
                                memory(mem_num) = struct('filename',list(i).name,'frame',fr,'cell',cell_list(j),'added','n','dist',[]);
                                mem_num = mem_num + 1;
                            end
                            
                            % if there is more than 1 peak
                        elseif length(idx) >2
                            
                            num = 1;
                            k_o = 1;
                            response = 'y';
                            %fprintf('%s: Cell %d\n',list(i).name,cell_list(j))
                            %response = input('Analyze this cell? Y/N','s');
                            if response == 'y'
                                for k = 1:length(idx)-1
                                    num = 1;
                                    if k < k_o
                                        display('Skipped peak')
                                    else
                                        ring_distance = sum(sqrt(diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2)).^2+diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2)).^2));
                                        while ring_distance < 30 && num+k < length(idx)
                                            num = num +1;
                                            ring_distance = sum(sqrt(diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2)).^2+diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2)).^2));
                                        end
                                        if ring_distance > 30 && num+k
                                            result='y';
                                            if result == 'y'
                                                k_o = num+k;
                                                num = 1;
                                                fprintf('Added: %3.2f\n', ring_distance)
                                                dist = [dist ring_distance];
                                                memory(mem_num) = struct('filename',list(i).name,'frame',fr,'cell',cell_list(j),'added','y','dist',ring_distance);
                                                mem_num = mem_num + 1;
                                            elseif result == 'm'
                                                while result ~= 'y' && num+k < length(idx)
                                                    num = num +1;
                                                    ring_distance = sum(sqrt(diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[1,3]),2)).^2+diff(mean(cont.frame(fr).object(cell_object_indx).mesh(x(idx(k))*2:x(idx(k+num))*2,[2,4]),2)).^2));
                                                    result = input('2. Add to distribution?','s');
                                                end
                                                if result == 'y'
                                                    k_o = num+k;
                                                    num = 1;
                                                    fprintf('Added: %3.2f\n', ring_distance)
                                                    dist = [dist ring_distance];
                                                    memory(mem_num) = struct('filename',list(i).name,'frame',fr,'cell',cell_list(j),'added','y','dist',ring_distance);
                                                    mem_num = mem_num + 1;
                                                    
                                                elseif result ~= 'y'
                                                    k_o = k;
                                                    num=1;
                                                    memory(mem_num) = struct('filename',list(i).name,'frame',fr,'cell',cell_list(j),'added','n','dist',[]);
                                                    mem_num = mem_num + 1;
                                                end
                                            else
                                                k_o = k;
                                                num=1;
                                                memory(mem_num) = struct('filename',list(i).name,'frame',fr,'cell',cell_list(j),'added','n','dist',[]);
                                                mem_num = mem_num + 1;
                                            end
                                        else
                                            fprintf('Did not pass %d',ring_distance)
                                        end
                                    end
                                end
                            else
                                memory(mem_num) = struct('filename',list(i).name,'frame',fr,'cell',cell_list(j),'added','n','dist',[]);
                                mem_num = mem_num + 1;
                            end
                        end
                    end
                end
            end
        end
    end
    eval(sprintf('%s=memory;',mem_var_name{z}))
end

%%
c = cbrewer('qual','Set1',5)
pxl = 0.064
[count1,center1] = hist([mem1.dist]*pxl,25)
%histogram([mem1.dist]*pxl,'BinWidth',1,'Normalization','probability','FaceColor',c(1,:))
hold on;
y = 0:0.1:0.4;
[count2,center2] = hist([mem2.dist]*pxl,35)
[count3,center3] = hist([mem3.dist]*pxl,50)
[count4,center4] = hist([mem4.dist]*pxl,50)
%histogram([mem2.dist]*pxl,'BinWidth',1,'Normalization','probability','FaceColor',c(2,:))
%histogram([mem3.dist]*pxl,'BinWidth',1,'Normalization','probability','FaceColor',c(3,:))
%histogram([mem4.dist]*pxl,'BinWidth',1,'Normalization','probability','FaceColor',c(4,:))
center1 = [min(center1) center1 max(center1)]
count1 = [0 count1 0]
center2 = [min(center2) center2 max(center2)]
count2 = [0 count2 0]
center3 = [min(center3) center3 max(center3)]
count3 = [0 count3 0]
center4 = [min(center4) center4 max(center4)]
count4 = [0 count4 0]

h1 = fill(center1,count1/numel(mem1),c(3,:),'FaceAlpha',0.4,'EdgeColor',c(3,:))
hold on;
h2 = fill(center2,count2/numel(mem2),c(4,:),'FaceAlpha',0.4,'EdgeColor',c(4,:))
%alpha(0.5)
h3 = fill(center3,count3/numel(mem3),c(1,:),'FaceAlpha',0.4,'EdgeColor',c(1,:))
%alpha(0.5)
h4 = fill(center4,count4/numel(mem4),c(2,:),'FaceAlpha',0.4,'EdgeColor',c(2,:))
%alpha(0.5)

%plot(median([mem1.dist]*pxl)*ones(1,length(y)),y,'Color',c(1,:))
%plot(median([mem2.dist]*pxl)*ones(1,length(y)),y,'Color',c(2,:))
%plot(median([mem3.dist]*pxl)*ones(1,length(y)),y,'Color',c(3,:))
%plot(median([mem4.dist]*pxl)*ones(1,length(y)),y,'Color',c(4,:))

% text(0.62,0.8,sprintf('median: %.3f �m',median([mem1.dist]*pxl)),'Units','normalized','Color',c(3,:))
% text(0.62,0.77,sprintf('median: %.3f �m',median([mem2.dist]*pxl)),'Units','normalized','Color',c(4,:))
% text(0.62,0.74,sprintf('median: %.3f �m',median([mem3.dist]*pxl)),'Units','normalized','Color',c(1,:))
% text(0.62,0.71,sprintf('median: %.3f �m',median([mem4.dist]*pxl)),'Units','normalized','Color',c(2,:))
text(7,0.15,'empty','Color',c(3,:),'FontSize',20)
text(8,0.135,'WT','Color',c(4,:),'FontSize',20)
text(6,0.18,'peri','Color',c(1,:),'FontSize',20)
text(9,0.125,'zapA/ydeI','Color',c(2,:),'FontSize',20)

%legend('pAM-empty','pAM-RcsF-WT','pAM-RcsF-peri','pAM-RcsF-peri (Zap Mutant)')
xlim([2 18])
set(gca,'XTick',0:2:18 );
set(gca,'YTick',0:0.02:0.18);
ylabel('Fraction')
xlabel('Separation between rings (�m)')
set(gca,'FontSize',20)
%set(findall(gcf,'type','text'),'FontSize',,'fontWeight','bold')
print('-dpdf','FtsZ-ring-dist-zapmutant.pdf')

%%
ph_image_folder='/Users/amiguel/Documents/Research/Projects/Nassos Typas RcsF FtsZ MreB/FtsZ rcsF/FtsZ imaging/15-03-05_FtsZ_sfGFP_all_strains_ceph35ugml/stacks';
gfp_image_folder='/Users/amiguel/Documents/Research/Projects/Nassos Typas RcsF FtsZ MreB/FtsZ rcsF/FtsZ imaging/15-03-05_FtsZ_sfGFP_all_strains_ceph35ugml/stacks/GFP';
cont_folder='/Users/amiguel/Documents/Research/Projects/Nassos Typas RcsF FtsZ MreB/FtsZ rcsF/FtsZ imaging/15-03-05_FtsZ_sfGFP_all_strains_ceph35ugml/stacks/Contours';
script_folder='/Users/amiguel/Documents/Research/Projects/Nassos Typas RcsF FtsZ MreB/FtsZ rcsF/FtsZ scripts';
cd(script_folder)
prefix='/*';
list = dir([cont_folder,prefix,'*.mat']);
list_gfp = dir([gfp_image_folder,prefix,'*GFP.tif']);
list_phase = dir([ph_image_folder,prefix,'*.tif']);


curv_thresh = -0.3;
for i = 1:numel(list)
    contourfile = [cont_folder,'/',list(i).name];
    im_idx_phase = get_image_index_from_contour(list(i).name,list_phase,'_19-Apr-2015_CONTOURS.mat','.tif');
    im_idx = get_image_index_from_contour(list(i).name,list_gfp,'_19-Apr-2015_CONTOURS.mat','_GFP.tif');
    if isnan(im_idx) || isnan(im_idx_phase)
    else
        imagefile = [gfp_image_folder,'/',list_gfp(im_idx).name];
        imagefile_ph = [gfp_image_folder,'/',list_gfp(im_idx).name];
    end
    %f = load(contourfile)
    [frame,cellid] = extract_filtered_cells(contourfile,curv_thresh);
    for j = 1:max(cellid)
        f_list = frame(find(j == cellid));
        if length(f_list) > 2
            [kymo,t]= contour_fluor_cell_time(contourfile,j,curv_thresh);
            figure(1);
            %subplot(1,2,1)
            imagesc(kymo)
            set(gca, 'YTickLabel', t)
            xlabel('Contour (pxl)')
            ylabel('Frame')
            colormap(gray);
            set(gca,'plotboxaspectratio',[0.5 1 1])
            
            %pause;
            output_name = strsplit(list(i).name,'_19-Apr-2015_CONTOURS.mat');
            output_name = output_name{1};
            print('-dpdf',[cont_folder,'/',sprintf('%s_%d_kymo.pdf',output_name,j)]);
            
            figure(2)
            %posV = [[0 0 0 .3 .3 .3 .7 .7 .7]',repmat([.7,.3,0]',3,1),.3*ones(1,9)',.3*ones(1,9)']
            title(sprintf('Cell %d',j))
            clf
            for l = 1:numel(f_list)
                subplot(3,3,l)
                %subplot('Position',posV(l,:))
                plotSingleCell_image_frame(imagefile_ph,contourfile,j,f_list(l))
            end
            print('-dpdf',[cont_folder,'/',sprintf('%s_%d_contours.pdf',output_name,j)])
            
        end
        
    end
end