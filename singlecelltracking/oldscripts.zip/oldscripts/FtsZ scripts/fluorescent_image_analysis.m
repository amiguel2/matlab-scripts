% Fluorescent image analysis scripts
function fluorescent_image_analysis(gfile,cfile,numframes,skipframes)
    
    load(cfile)
    
    % read in fluorescent image
    for i = 0:skipframes:numframes
        imagefile= gfile;
        image = imread(imagefile);
        for j = 1:length(frame(i+1).object)
            x = frame(i+1).object(j).Xcont;
            y = frame(i+1).object(j).Ycont;
            Int = zeros(length(x),3);
            Int = find_Intensities(x,y,image);
        end
    end
end

function I = find_Intensities(X,Y,image)
    n = length(X);
    a = -3:.6:3;
    I = zeros(11,n);
    for i = 1:n
           if i == 1
               vector = [X(i+1),Y(i+1)] - [X(n),Y(n)];
           elseif i == n
               vector = [X(1),Y(1)] - [X(i-1),Y(i-1)];
           else
               vector = [X(i+1),Y(i+1)] - [X(i-1),Y(i-1)];
           end

           n_vector = [vector(2),-vector(1)] / norm(vector,2);
           
           r = repmat([X(i),Y(i)],11,1);
           n_points = r + a*n_vector;
           I(i) = [X(i),Y(i),sum(interp2(image,n_points(:,1),n_points(:,2)),1)];
           
    end
    return 
end