function fp = contour_fluor_cell(contourfile,cellID,fr)
    cont = load(contourfile);
    cf = cell_frames(cont.frame);
    f = find(cf{cellID} == fr);
    
    ids = extractfield(cont.frame(cf{cellID}(f)).object,'cellID');
    idx = find(ids == cellID);
    fp = cont.frame(cf{cellID}(f)).object(idx).fluor_profile;
    
end