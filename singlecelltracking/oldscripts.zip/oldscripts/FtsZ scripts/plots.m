figure(2)

[counts,centers]=hist(extractfield(Empty_fr20_ftszring,'dist')*.064,20);
c = counts/length(extractfield(Empty_fr20_ftszring,'dist'));
b = bar(centers,c,1,'hist','w');
%set(b,'FaceAlpha',0.1,'EdgeColor','b');
set(b,'EdgeColor','flat','FaceColor','w')
hold on;

[counts,centers]=hist(extractfield(wt_fr20_ftszring,'dist')*.064,20);
c = counts/length(extractfield(wt_fr20_ftszring,'dist'));
b1 = bar(centers,c,1,'hist','r');
set(b1,'FaceAlpha',0.1,'EdgeColor','r');

[counts,centers]=hist(extractfield(peri_fr20_ftszring,'dist')*.064,20);
c = counts/length(extractfield(peri_fr20_ftszring,'dist'));
b2 = bar(centers,c,1,'hist','black');
set(b2,'FaceAlpha',0.1,'EdgeColor','black');

% [counts,centers]=hist(extractfield(zap_nodeg3_cells,'dist')*.064);
% c = counts/length(extractfield(zap_nodeg3_cells,'dist'));
% b3 = bar(centers,c,1,'hist','g');
% set(b3,'FaceAlpha',0.1,'EdgeColor','g');

plot(ones(1,2)*mean(extractfield(empty_fr1_ftszring,'dist')*.064),[0 0.5],'b--')
plot(ones(1,2)*mean(extractfield(wt_fr1_ftszring,'dist')*.064),[0 0.5],'r--')
plot(ones(1,2)*mean(extractfield(peri_fr1_ftszring,'dist')*.064),[0 0.5],'black--')
plot(ones(1,2)*mean(extractfield(zap_nodeg3_cells,'dist')*.064),[0 0.5],'g--')

legend('Empty: frame 20','WT: frame 20','Peri-mutant: frame: 20','Empty: frame 1','WT: frame 1','Peri-mutant: frame: 1','Zap-mutant')
plot(ones(1,2)*mean(extractfield(Empty_fr20_ftszring,'dist')*.064),[0 0.5],'b','LineWidth',2)
plot(ones(1,2)*mean(extractfield(wt_fr20_ftszring,'dist')*.064),[0 0.5],'r','LineWidth',2)
plot(ones(1,2)*mean(extractfield(peri_fr20_ftszring,'dist')*.064),[0 0.5],'black','LineWidth',2)
%plot(ones(1,2)*mean(extractfield(zap_nodeg3_cells,'dist')*.064),[0 0.5],'g')

ylabel('Normalized Counts')
xlabel('Width (�m)')
xlim([0 20])

%%
figure(1)
[counts,centers]=hist(extractfield(empty_fr1_ftszring,'dist')*.064);
c = counts/length(extractfield(empty_fr1_ftszring,'dist'));
b3 = bar(centers,c,1,'hist','b');
set(b3,'FaceAlpha',0.1,'EdgeColor','b');
hold on;
[counts,centers]=hist(extractfield(wt_fr1_ftszring,'dist')*.064);
c = counts/length(extractfield(wt_fr1_ftszring,'dist'));
b1 = bar(centers,c,1,'hist','r');
set(b1,'FaceAlpha',0.1,'EdgeColor','r');

[counts,centers]=hist(extractfield(peri_fr1_ftszring,'dist')*.064);
c = counts/length(extractfield(peri_fr1_ftszring,'dist'));
b2 = bar(centers,c,1,'hist','black');
set(b2,'FaceAlpha',0.1,'EdgeColor','black');

[counts,centers]=hist(extractfield(zap_nodeg3_cells,'dist')*.064);
c = counts/length(extractfield(zap_nodeg3_cells,'dist'));
b3 = bar(centers,c,1,'hist','g');
set(b3,'FaceAlpha',0.1,'EdgeColor','g');

plot(ones(1,2)*mean(extractfield(empty_fr1_ftszring,'dist')*.064),[0 0.5],'b--','LineWidth',2)
plot(ones(1,2)*mean(extractfield(wt_fr1_ftszring,'dist')*.064),[0 0.5],'r--','LineWidth',2)
plot(ones(1,2)*mean(extractfield(peri_fr1_ftszring,'dist')*.064),[0 0.5],'black--','LineWidth',2)
plot(ones(1,2)*mean(extractfield(zap_nodeg3_cells,'dist')*.064),[0 0.5],'g--','LineWidth',2)

legend('Empty: frame 1','WT: frame 1','Peri-mutant: frame 1','Zap-mutant')
ylabel('Normalized Counts')
xlabel('Width (�m)')
xlim([0 20])
Title('First Frame')
