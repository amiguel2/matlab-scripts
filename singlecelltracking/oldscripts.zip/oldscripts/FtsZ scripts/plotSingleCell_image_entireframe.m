function plotSingleCell_image_frame(image,contour_file,cID,fr) 

    c = load(contour_file);
    
    % a cell array where index references cell id and c{i} is a vector
    % of the frames
        
    %extracts all cell ids in frame(i).objects
    cids = extractfield(c.frame(fr).object, 'cellID');

    %finds the index that matches the same cell ID
    idx = find(cids == cID);

    %outputs the indexes
    cellid = idx;
        
     xPos_max = max(c.frame(fr).object(cellid).Xcont);
     xPos_min = min(c.frame(fr).object(cellid).Xcont);
     xd = xPos_max - xPos_min;
     yPos_max = max(c.frame(fr).object(cellid).Ycont);
     yPos_min = min(c.frame(fr).object(cellid).Ycont);
     yd = yPos_max - yPos_min;
    if isfield(c.frame(fr).object(cellid),'mesh')
        m = c.frame(fr).object(cellid).mesh;
    else
        m = c.frame(fr).object(cellid).MT_mesh;
    end
     
     fprintf('Cell %s...\n',num2str(c.frame(fr).object(cellid).cellID));


    % for every frame
        im = imread(image,fr);
        [counts,x] = imhist(im);
        imshow(im,[0 x(find(counts>0,1,'last'))]);
        xlim([0 2560]);
        ylim([0 2160]);
        hold on;
        if isfield(c.frame(fr).object(cellid),'mesh');
            m = c.frame(fr).object(cellid).mesh;
        else
            m = c.frame(fr).object(cellid).MT_mesh;
        end
        plot(c.frame(fr).object(cellid).Xcont,c.frame(fr).object(cellid).Ycont,'red')
        hold on;
        text(m(1,3),m(1,4),num2str(c.frame(fr).object(cellid).cellID),'Color',[0 0 0])
        %plot([m(:,3),m(:,1)],[m(:,4),m(:,2)],'yellow')
        %pause(.00000001);
end
