% Fluorescent image analysis scripts

function fluorescent_image_analysis(filepattern,cfile,numframes)

    a = -3:.6:3;

    load(cfile)
    for i = 0:1:numframes
        imagefile= strcat(filepattern,sprintf('%03d',i),'.tif';
        I = imread(imagefile);
        for j = 1:len(frame(i).object)
            x = frame(i).object(j).Xcont;
            y = frame(i).object(j).Ycont;
            Int = zeros(length(x),3);
            Int = find_Intensities(x,y,image);
        end
    end
    
    
end

function I = find_Intensities(Xcont,Ycont,image)
    n = len(Xcont);
    I = zeros(1,n);
    for i = 1:n
           if i == 1
               vector = [Xcont(i+1),Ycont(i+1)] - [Xcont(n),Ycont(n)];
           elseif i == n
               vector = [Xcont(1),Ycont(1)] - [Xcont(i-1),Ycont(i-1)];
           else
               vector = [Xcont(i+1),Ycont(i+1)] - [Xcont(i-1),Ycont(i-1)];

           end

           n_vector = [vector(2),-vector(1)] / norm(vector,2);
           
           r = repmat([Xcont(i),Ycont(i)],11,1);
           n_points = r + a*n_vector;
           I(i) = interp2(image,n_points[:,1],n_points[:,2]
           
    end
end

%%%%%% MAIN %%%%%%%%%%%

fluorescent_image_analysis(filepattern,cfile,numframes)
