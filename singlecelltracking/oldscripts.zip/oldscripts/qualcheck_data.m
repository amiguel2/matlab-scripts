function qualcheck_data(data,list)
for i = 1:numel(list)
    fprintf('%s\n',list(i).name)
    f = load(list(i).name);
    plotAllCells(f,'cellid',get_cids(data,list(i).name),'show_cellid',1)
end
end