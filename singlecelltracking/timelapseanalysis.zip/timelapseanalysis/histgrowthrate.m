function datastruct = histgrowthrate(datastruct)
color = cbrewer('qual','Set1',numel(datastruct));
fgrtotals = {};
for a = 1:numel(datastruct)
    cells = datastruct{a}.cells;
    fgr = [];
    for i = 1:numel(cells)
        fgr = [fgr getfittedgr(cells{i})];
        if ~isfield(cells{i},'fitgrowthrate')
            [cells{i}.fitgrowthrate] = deal(fgr);
        end
    end
    fgrtotals = [fgrtotals fgr];
end

bins = [30 40 30 30];
datastruct{a}.cells = cells;
for b = 1:numel(fgrtotals)
    f = fgrtotals{b};
    hist_transparent(f(f > -0.2),bins(b),color(b,:));
    hold on;
end
end

function x = getfittedgr(cell)
if ~isfield(cell,'fitgrowthrate')
    l = smooth(getlength(cell))';
    t = gettime(cell);
    beta = [l(1) 0.025];
    [beta,r] = nlinfit(t,l,@expfit,beta);
    x = beta(2);
else
    x = [extractfield(cell,'fitgrowthrate')];
    x = x(1);
end
end

function x = getlength(cell)
x = [extractfield(cell,'cell_length')];
end

function x = getwidth(cell)
x = [extractfield(cell,'cell_width')];
end

function x = gettime(cell)
x = [extractfield(cell,'frame')];
end