function plotcellshape(cell)
for i = 1:numel(cell)
   x = cell(1,i).Xcont;
   y = cell(1,i).Ycont;
   scatter(x,y)
   axis equal;
   hold on;
   pause;
end
end