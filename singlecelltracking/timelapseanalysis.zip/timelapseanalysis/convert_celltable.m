list = dir('*CONTOURS.mat')
for i = 1:numel(list)
    f = load(list(i).name);
    make_celltable(f)
end