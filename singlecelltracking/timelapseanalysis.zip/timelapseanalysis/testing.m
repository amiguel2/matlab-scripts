% looking at length

for i = 1:numel(A22.c0.cells)
    subplot(1,2,1)
    plot(extractfield(A22.c0.cells{i},'frame'),extractfield(A22.c0.cells{i},'cell_length')); hold on;
    subplot(1,2,2)
    plot(extractfield(A22.c0.cells{i},'frame'),extractfield(A22.c0.cells{i},'cell_width')); hold on;
end

%% looking at width
dw = []


for i = 1:numel(A22.c0.cells)
    dw = [dw diff(extractfield(A22.c0.cells{i},'cell_width'))];
    %plot(extractfield(A22.c0.cells{i},'frame'),extractfield(A22.c0.cells{i},'cell_width')); hold on;
end
hist(dw,100)
%% looking at cell contour
% dl = []
for i = 1:numel(A22.c0.cells)
%     dl = [dl diff(extractfield(A22.c0.cells{i},'cell_length'))];
plot(extractfield(A22.c0.cells{i},'Xcont'),extractfield(A22.c0.cells{i},'Ycont')); hold on;
% for j = 1:numel(A22.c0.cells{i})
% plot(extractfield(A22.c0.cells{i}(j),'Xcont'),extractfield(A22.c0.cells{i}(j),'Ycont')); hold on;
% scatter(extractfield(A22.c0.cells{i}(1),'frame'),extractfield(A22.c0.cells{i}(1),'cell_width')); hold on;
% plot(mean(A22.c0.cells{i}(1).mesh(:,[1,3]),2),mean(A22.c0.cells{i}(1).mesh(:,[2,4]),2))
% end
hold off;
axis equal
pause;

end
%% look at histogram
hist(extractfield(A22.c0.cells{i},'cell_w'))

%% 
xmed = mean(A22.c0.cells{i}(1).mesh(:,[1,3]),2);
ymed = mean(A22.c0.cells{i}(1).mesh(:,[2,4]),2);
plot(A22.c0.cells{i}(1).mesh(:,[1,3]),A22.c0.cells{i}(1).mesh(:,[2,4])); hold on;
plot(xmed,ymed)
plot(linspace(xmed(1),xmed(end),numel(xmed)),linspace(ymed(1),ymed(end),numel(xmed)))
