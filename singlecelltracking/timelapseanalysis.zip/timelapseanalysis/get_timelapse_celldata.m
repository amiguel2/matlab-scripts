function data = get_timelapse_celldata(list,varargin)
%% get_timelapse_celldata: reorganizes dataset into a cell structure of individual cells
% Optional Parameters:
% pxl [Default: 0.0652] the pixel to micron ratio
% tinterval[Default: 2] the time interval fo the frames 

%script directory
cd '/Users/amiguel/Dropbox/MATLAB/matlab_scripts/timelapseanalysis/'

% setting paramaters
args = varargin;
param = set_funcparam(args,numel(list));

cells = {};
%% get all cells
param.maxf = [];
for i = 1:numel(list)
   f = load(list(i).name);
   cells = [cells getcells(f,i,param)];
   if i == 1
        param.maxf = numel(f.frame);
   end
end
%% filter cells
% cells = filtcells(cells);
data.cells = cells;

% setup data export
% param.maxf = numel(f.frame);
if ~isfield(param,'maxt')
    param.maxt = param.maxf*param.tinterval;
end
data.param = param;
data.list = list;
end

function cells = getcells(f,listidx,param)
    % remove all cells with `only one frame
    if ~isfield(f,'cells')
        if isfield(f,'cell')
        f.cells.frame = [f.cell.frames];
        f.cells.object = [f.cell.bw_label];
        else
         f = make_celltable(f);     
        end
    end
    cids = find(cellfun(@numel,{f.cells.frame}) > 3);
    cells = {};
    for i = cids
        singlecell = [];
        fr = f.cells(i).frame;
        ob = f.cells(i).object;
        for j = 1:numel(fr)
            f.frame(fr(j)).object(ob(j)).frame = fr(j);
            f.frame(fr(j)).object(ob(j)).t = (fr(j)*param.tinterval)+(param.tstart(listidx)-1);
%             if sum(extractfield(f.frame(fr(j)).object(ob(j)),'kappa_raw') < -0.2)+sum(extractfield(f.frame(fr(j)).object(ob(j)),'kappa_raw') > 0.5) >2
%                 continue;
%             end
%             if isempty(f.frame(fr(j)).object(ob(j)).cell_length)
%                 continue;
%             end
%             try
            singlecell = [singlecell f.frame(fr(j)).object(ob(j))];
%             end
        end
        if numel(singlecell) > 1
            cells = [cells singlecell];
        end
    end
end

function cells = filtcells(cells)
idx = [];
for i = 1:numel(cells)
   l = extractfield(cells{i},'cell_length');
   w = extractfield(cells{i},'cell_width');
   if sum(abs(diff(l)) > 10) < 1 && sum(abs(diff(w)) > 2) < 1
    idx = [idx i];
   end
end
cells = cells(idx);

end

function paramset = set_funcparam(args,N)
% default parameters
paramset.pxl = 0.0652; % polaris pixel ratio
paramset.tinterval = 2;
paramset.tstart = ones(1,N);

if ~isempty(args)
    evennumvars = mod(numel(args),2);
    if evennumvars
        fprintf('Too many arguments. Use: get_data(list,tframe,pxl,[optional] fluor lineage tshift microbej onecolor)\n')
        return
    end
    
    for i = 1:2:numel(args)
        eval(sprintf('paramset.%s = args{%d};',args{i},i+1));
    end
end

end