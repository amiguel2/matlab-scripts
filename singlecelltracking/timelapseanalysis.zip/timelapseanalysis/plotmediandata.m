function plotmediandata(datastruct)
figure('Color',[1 1 1 ],'Position',[0 0 800 500]);
subplotx = 2;
subploty = 2;
names = fieldnames(datastruct);
color = cbrewer('qual','Set1',numel(names));
for a = 1:numel(names)
   c =  color(a,:);
   data = datastruct.(names{a});
   if ~isfield(data,'mediandata')
       continue
   end
   maxt = data.param.maxt;
%    xlimparam = 60;
   md = data.mediandata;
   t = 1:numel(md);
   [med,ste] = getmedian(md);
   plotmed(t,med.l,c,[subplotx,subploty,1])
   plotmed(t,med.w,c,[subplotx,subploty,2])
   plotmed(t,med.gr,c,[subplotx,subploty,3])
   plotmed(t,med.fl,c,[subplotx,subploty,4])
   
   ploterr(t,med.l,ste.l,c,[subplotx,subploty,1])
   ploterr(t,med.w,ste.w,c,[subplotx,subploty,2])
   ploterr(t,med.gr,ste.gr,c,[subplotx,subploty,3])
   ploterr(t,med.fl,ste.fgr,c,[subplotx,subploty,4])
   
end

setgraphlabels(maxt,[subplotx,subploty])
end

function [med,ste] = getmedian(totaldata)
med.l = NaN(1,numel(totaldata));
med.w = NaN(1,numel(totaldata));
med.gr = NaN(1,numel(totaldata));
med.fgr = NaN(1,numel(totaldata));
med.fl = NaN(1,numel(totaldata));
med.a = NaN(1,numel(totaldata));
ste.l = NaN(1,numel(totaldata));
ste.w = NaN(1,numel(totaldata));
ste.gr = NaN(1,numel(totaldata));
ste.fgr = NaN(1,numel(totaldata));

for i = 1:numel(totaldata)
    if numel(totaldata(i).l) > 2
    med.l(i) = nanmedian(totaldata(i).l);
    ste.l(i) = nanstd(totaldata(i).l)/sum(~isnan(totaldata(i).l));
    med.w(i) = nanmedian(totaldata(i).w);
    ste.w(i) = nanstd(totaldata(i).w)/sum(~isnan(totaldata(i).l));
    med.gr(i) = nanmedian(totaldata(i).gr);
    ste.gr(i) = nanstd(totaldata(i).gr)/sum(~isnan(totaldata(i).l));
    med.fgr(i) = nanmedian(totaldata(i).fgr);
    ste.fgr(i) = nanstd(totaldata(i).fgr)/sum(~isnan(totaldata(i).l));
    
    med.fl(i) = nanmedian(totaldata(i).fl);
    med.a(i) = nanmedian(totaldata(i).ar);
    end
        
end

end
function plotmed(x,y,c,subplotnum)
subplot(subplotnum(1),subplotnum(2),subplotnum(3))
plot(x(~isnan(y)),y(~isnan(y)),'Color',c,'LineWidth',2); hold on;
h = scatter(x(~isnan(y)),y(~isnan(y)),10,c,'filled');
h.Annotation.LegendInformation.IconDisplayStyle = 'off';
end
function ploterr(x,y,e,c,subplotnum)
E = e(~isnan(y));
Y = y(~isnan(y));
X = x(~isnan(y));
subplot(subplotnum(1),subplotnum(2),subplotnum(3))
yupperbound = Y+E;
ylowerbound = Y-E;
p = patch([X, flip(X)],[ylowerbound,flip(yupperbound)],c,'FaceAlpha',0.2,'EdgeColor','none');
% p.Annotation.LegendInformation.IconDisplayStyle = 'off';
% h = errorbar(x(~isnan(y)),y(~isnan(y)),e(~isnan(y)),'Color',c);
% h.Annotation.LegendInformation.IconDisplayStyle = 'off';
end

function setgraphlabels(maxt,subplotnum)
subplot(subplotnum(1),subplotnum(2),1)
title('Length')
ylim([0 6])
xlim([0 maxt])
ylabel('Length (um)')
xlabel('Time (min)')
subplot(subplotnum(1),subplotnum(2),2)
title('Width')
ylim([0.5 2])
xlim([0 maxt])
ylabel('Width (um)')
xlabel('Time (min)')
subplot(subplotnum(1),subplotnum(2),3)
title('Instantaneous Growthrate')
ylim([-0.02 0.06])
xlim([0 maxt])
ylabel('Growthrate (min^-1) ')
xlabel('Time (min)')
subplot(subplotnum(1),subplotnum(2),4)
title('Fluorescence')
ylim([0 800])
xlim([0 maxt])
ylabel('Fluorescence (A.U.)')
xlabel('Time (min)')
end