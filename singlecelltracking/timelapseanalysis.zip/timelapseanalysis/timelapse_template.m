clear; close all;
folder = '/Users/amiguel/Dropbox/Research Data/Rcs System/RCS42 cellasic M9/AM_IM123/';
%folder = '/scratch/users/amiguel2/Working_Folder/Rcs_system/AM_IM123/M9_cellasic_IPTG_EWPI_100ms_Phase_200ms_GFP_2/stacks/';
cd(folder)
% mesh_contours

M9.em.list = rdir([folder '*3-Pos*CONTOURS.mat']);
M9.wt.list = rdir([folder '*4-Pos*CONTOURS.mat']);
M9.peri.list = rdir([folder '*6-Pos*CONTOURS.mat']);
M9.im.list = rdir([folder '*5-Pos*CONTOURS.mat']);


M9.em = get_timelapse_celldata(M9.em.list,'pxl',0.08,'tinterval',4,'maxt',776);
% M9.wt = get_timelapse_celldata(M9.wt.list,'pxl',0.08,'tinterval',4,'maxt',776);
% M9.peri = get_timelapse_celldata(M9.peri.list,'pxl',0.08,'tinterval',4,'maxt',776);
% M9.im = get_timelapse_celldata(M9.im.list,'pxl',0.08,'tinterval',4,'maxt',776);
% cd(folder)


%%
M9.em.cells = filtcells(M9.em.cells);
M9.wt.cells = filtcells(M9.wt.cells);
M9.peri.cells = filtcells(M9.peri.cells);
M9.im.cells = filtcells(M9.im.cells);

%%
M9 = plotcelldata(M9,'wt');
savefig('wt-data.fig')
close all;
M9 = plotcelldata(M9,'im');
savefig('im-data.fig')
close all;
M9 = plotcelldata(M9,'peri');
savefig('peri-data.fig')

figure;
plotmediandata(M9);

subplot(2,2,1);plot([54 54],[0 4],'black','LineStyle',':');ylim([2 4]);
subplot(2,2,2);plot([54 54],[0 4],'black','LineStyle',':');ylim([1 1.2]);
subplot(2,2,3);plot([54 54],[0 4],'black','LineStyle',':');ylim([0.0002 0.01])
savefig('data-noem.fig')

M9 = plotcelldata(M9,'em');
savefig('em-data.fig')
close all;

%%
figure;
plotmediandata(M9);

subplot(2,2,1);plot([54 54],[0 4],'black','LineStyle',':');ylim([2 4]);prettifyplot
subplot(2,2,2);plot([54 54],[0 4],'black','LineStyle',':');ylim([0.92 1.2]);prettifyplot
subplot(2,2,3);plot([54 54],[0 4],'black','LineStyle',':');ylim([0.0002 0.01]);prettifyplot
subplot(2,2,4);plot([54 54],[0 800],'black','LineStyle',':');ylim([0 800]);prettifyplot
savefig('data-all.fig')
export_fig('data-all.pdf')
%%

figure;
plotmediandata(dwcaJ.data);
subplot(2,2,1);xlim([0 120]); ylim([1 6]); prettifyplot
subplot(2,2,2);xlim([0 120]); ylim([1 1.5]); prettifyplot
subplot(2,2,3);xlim([0 120]); ylim([0.01 0.03]); prettifyplot
subplot(2,2,4);xlim([0 120]); ylim([0.01 0.03]);prettifyplot
export_fig('am112-medianplots.pdf')
savefig('am112-medianplots.fig')
save('am112-data-04-14.mat')

% subplot(2,2,1);legend('Empty','WT','Peri','IM');
% subplot(2,2,1); ylim([0 20])
% h = subplot(2,2,4);
% delete(h)
% output = folder;
% export_fig([output 'IPTG_mediandata.pdf'])
% savefig([output 'IPTG_mediandata.fig'])
% save('IPTG-ceph.mat')
%%
figure;
c = cbrewer('qual','Set1',5);
data = dwcaJ.data.im.cells;
for i = 1:numel(data)
scatter(data{i}(1).t,data{i}(1).fitgrowthrate,50,c(4,:),'filled'); hold on;
end
medfgr = [];
for i = 1:numel(dwcaJ.data.im.mediandata)
    medfgr = [medfgr nanmedian(dwcaJ.data.im.mediandata(i).fgr)];
end
x = 1:numel(medfgr);
plot(x(~isnan(medfgr)),medfgr(~isnan(medfgr)),'LineWidth',2)
ylim([0 0.04])






