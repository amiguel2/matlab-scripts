function datastruct = plotcelldata(datastruct,varargin)
subplotx = 2;
subploty = 4;
outputdata = {};
dataisstruct = 0;
if iscell(datastruct)
    N = numel(datastruct);
else
    fn = fieldnames(datastruct);
    N = numel(fn);
    dataisstruct = 1;
end

if numel(varargin) > 0
    subset = varargin{1};
else
    subset = fn;
end
color = cbrewer('qual','Set1',N);
for a = 1:N
    
    % setup default params and structures
    if dataisstruct
        if sum(strcmp(fn{a},subset))
            data = datastruct.(fn{a});
        else
            continue;
        end
    else
        data = datastruct{a};
    end
    c = color(a,:) + [0.5 0.5 0.5];
    c(c>1) = 1;
    cells = data.cells;
    param = data.param;
    pxl = param.pxl;
    maxt = param.maxt;
    if isfield(param,'tstart')
        tstart = param.tstart;
    else
        tstart = 1;
    end
    if ~isfield(data,'mediandata')
        mediandata = struct('l',NaN,'w',NaN,'gr',NaN,'fgr',NaN,'ar',NaN,'fl',NaN);
        for i = 2:maxt+10
            mediandata = [mediandata struct('l',NaN,'w',NaN,'gr',NaN,'fgr',NaN,'ar',NaN,'fl',NaN)];
        end
    else
        mediandata = data.mediandata;
    end
    
    % for each cell
    for i = 1:numel(cells)
        % getting cell parameters
        l = getlength(cells{i})*pxl;
        w = getwidth(cells{i})*pxl;
        t = gettime(cells{i});
        %t = gettime(cells{i})*param.tinterval;
        gr = getgrowthrate(cells{i});
        fl = getfluor(cells{i})*pxl;
        ar = getarea(cells{i})*pxl*pxl;
        if ~isfield(cells{i},'growthrate')
            gr = [NaN gr];
            cgr = num2cell(gr);
            [cells{i}.growthrate] = deal(cgr{:});
           
        end
        fgr = NaN;%getfittedgr(cells{i});
%         if ~isfield(cells{i},'fitgrowthrate')
%             [cells{i}.fitgrowthrate] = deal(fgr);
%         end
    
    % storing data
    if ~isfield(data,'mediandata')
        for j = 1:numel(t)
            try
            mediandata(t(j)).l = [mediandata(t(j)).l l(j)];
            mediandata(t(j)).w = [mediandata(t(j)).w w(j)];
            mediandata(t(j)).gr = [mediandata(t(j)).gr gr(j)];
            mediandata(t(j)).ar = [mediandata(t(1)).ar ar(j)];
            if ~isempty(fl)
                mediandata(t(j)).fl = [mediandata(t(j)).fl fl(j)];
            end
            end
        end
        try
        mediandata(t(1)).fgr = [mediandata(t(1)).fgr fgr];
        end
        
        data.cells = cells;
        
        if dataisstruct
            datastruct.(fn{a}) = data;
        else
            datastruct{a} = data;
        end
    end
    
    % plotting
    subplot(2,4,1)
    h =plot(t,l,'Color',c); hold on;
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    subplot(2,4,2)
    h =plot(t,w,'Color',c); hold on;
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    subplot(2,4,3)
    h =plot(t,gr,'Color',c); hold on;
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    subplot(2,4,4)
    scatter(t(1),fgr,50,c,'filled'); hold on;

    if ~isempty(fl)
        subplot(2,4,5)
        plot(t,fl,'Color',c); hold on;
    end
    subplot(2,4,6)
    h =plot(t,ar,'Color',c); hold on;
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    end

    
    
    
% plotmedian(mediandata,color(a,:))
t = 1:numel(mediandata);
[med,ste] = getmedian(mediandata);
plotmed(t,med.l,color(a,:),[subplotx,subploty,1])
plotmed(t,med.w,color(a,:),[subplotx,subploty,2])
plotmed(t,med.gr,color(a,:),[subplotx,subploty,3])
plotmed(t,med.fgr,color(a,:),[subplotx,subploty,4])
ploterr(t,med.l,ste.l,color(a,:),[subplotx,subploty,1])
ploterr(t,med.w,ste.w,color(a,:),[subplotx,subploty,2])
ploterr(t,med.gr,ste.gr,color(a,:),[subplotx,subploty,3])
ploterr(t,med.fgr,ste.fgr,color(a,:),[subplotx,subploty,4])

if ~isempty(fl)
    plotmed(t,med.fl,color(a,:),[subplotx,subploty,5])
    ploterr(t,med.fl,ste.fl,color(a,:),[subplotx,subploty,5])
end

if ~isfield(data,'mediandata')
    if dataisstruct
        datastruct.(fn{a}).mediandata = mediandata;
    else
        datastruct{a}.mediandata = mediandata;
    end
end
end
% set graph labels/axis
setgraphlabels(maxt)
end


function [med,ste] = getmedian(totaldata)
med.l = NaN(1,numel(totaldata));
med.w = NaN(1,numel(totaldata));
med.gr = NaN(1,numel(totaldata));
med.fgr = NaN(1,numel(totaldata));
med.fl = NaN(1,numel(totaldata));
med.a = NaN(1,numel(totaldata));
ste.l = NaN(1,numel(totaldata));
ste.w = NaN(1,numel(totaldata));
ste.gr = NaN(1,numel(totaldata));
ste.fgr = NaN(1,numel(totaldata));

for i = 1:numel(totaldata)
    med.l(i) = nanmedian(totaldata(i).l);
    ste.l(i) = nanstd(totaldata(i).l)/sum(~isnan(totaldata(i).l));
    med.w(i) = nanmedian(totaldata(i).w);
    ste.w(i) = nanstd(totaldata(i).w)/sum(~isnan(totaldata(i).w));
    med.gr(i) = nanmedian(totaldata(i).gr);
    ste.gr(i) = nanstd(totaldata(i).gr)/sum(~isnan(totaldata(i).gr));
    med.fgr(i) = nanmedian(totaldata(i).fgr);
    ste.fgr(i) = nanstd(totaldata(i).fgr)/sum(~isnan(totaldata(i).fgr));
    med.fl(i) = nanmedian(totaldata(i).fl);
    ste.fl(i) = nanstd(totaldata(i).fl)/sum(~isnan(totaldata(i).fl));
    med.a(i) = nanmedian(totaldata(i).ar);
    ste.a(i) = nanstd(totaldata(i).ar)/sum(~isnan(totaldata(i).ar));
end

end
function plotmed(x,y,c,subplotnum)
subplot(subplotnum(1),subplotnum(2),subplotnum(3))
plot(x(~isnan(y)),y(~isnan(y)),'Color',c,'LineWidth',3); hold on;
end
function ploterr(x,y,e,c,subplotnum)
subplot(subplotnum(1),subplotnum(2),subplotnum(3))
h = errorbar(x(~isnan(y)),y(~isnan(y)),e(~isnan(y)),'Color',c,'LineWidth',3);
h.Annotation.LegendInformation.IconDisplayStyle = 'off';
end

function plotmedian(totaldata,c)
t = 1:numel(totaldata);
medianl = NaN(1,numel(totaldata));
medianw = NaN(1,numel(totaldata));
mediangr = NaN(1,numel(totaldata));
medianfgr = NaN(1,numel(totaldata));
medianar = NaN(1,numel(totaldata));
medianfl = NaN(1,numel(totaldata));
for i = 1:numel(totaldata)
    medianl(i) = nanmedian(totaldata(i).l);
    medianw(i) = nanmedian(totaldata(i).w);
    mediangr(i) = nanmedian(totaldata(i).gr);
    medianfgr(i) = nanmedian(totaldata(i).fgr);
    medianar(i) = nanmedian(totaldata(i).ar);
    
    medianfl(i) = nanmedian(totaldata(i).fl);
end
subplot(2,4,1)
plot(t(~isnan(medianl)),medianl(~isnan(medianl)),'Color','black','LineWidth',4)
subplot(2,4,2)
plot(t(~isnan(medianw)),medianw(~isnan(medianw)),'Color','black','LineWidth',4)
subplot(2,4,3)
plot(t(~isnan(mediangr)),mediangr(~isnan(mediangr)),'Color','black','LineWidth',4)
subplot(2,4,4)
plot(t(~isnan(medianfgr)),mediangr(~isnan(medianfgr)),'Color','black','LineWidth',4)
subplot(2,4,5)
plot(t(~isnan(medianfl)),mediangr(~isnan(medianfl)),'Color','black','LineWidth',4)
subplot(2,4,6)
plot(t(~isnan(medianar)),mediangr(~isnan(medianar)),'Color','black','LineWidth',4)
end

function setgraphlabels(maxt)
subplot(2,4,1)
title('Length')
% ylim([0 10])
xlim([0 maxt])
ylabel('Length (um)')
xlabel('Time (min)')
subplot(2,4,2)
title('Width')
% ylim([0.5 1.5])
xlim([0 maxt])
ylabel('Width (um)')
xlabel('Time (min)')
subplot(2,4,3)
title('Instantaneous Growthrate')
 ylim([-0.02 0.06])
xlim([0 maxt])
ylabel('Growthrate (min^-1) ')
xlabel('Time (min)')
subplot(2,4,4)
title('Fitted Growthrate')
ylim([-0.02 0.06])
xlim([0 maxt])
ylabel('Growthrate (min^-1) ')
xlabel('Time (min)')
subplot(2,4,5)
title('Fluorescence')
% ylim([0 150])
xlim([0 maxt])
ylabel('Fluorescence (A.U)')
xlabel('Time (min)')
subplot(2,4,6)
title('Area')
% ylim([0 10])
xlim([0 maxt])
ylabel('Area (um^2)')
xlabel('Time (min)')
end

function x = getgrowthrate(cell)
if ~isfield(cell,'growthrate')
%     a = smooth(getarea(cell))';
    a = smooth(getlength(cell))';
    t = gettime(cell);
    if numel(a) > 2
        x = log(a(2:end)./a(1:end-1))./double(diff(t));
    else
        x = NaN;
    end
else
    x = [extractfield(cell,'growthrate')];
end
end

function x = getfittedgr(cell)
if ~isfield(cell,'fitgrowthrate')
%     a = smooth(getarea(cell))';
    a = smooth(getlength(cell))';
    t = gettime(cell);
    beta = [a(1) 0.025];
    try
    [beta,r] = nlinfit(t,a,@expfit,beta);
    x = beta(2);
    catch
        x = NaN;
    end
else
    x = [extractfield(cell,'fitgrowthrate')];
    x = x(1);
end
end

function x = getlength(cell)
try
    x = [extractfield(cell,'cell_length')];
catch
    x = [extractfield(cell,'length')];
end
end

function x = getwidth(cell)
x = [extractfield(cell,'cell_width')];
end

function x = gettime(cell)
% x = [extractfield(cell,'frame')];
x = [extractfield(cell,'t')];
end

function x = getarea(cell)
x = [extractfield(cell,'area')];
end

function x = getfluor(cell)
x = [];
if isfield(cell,'ave_fluor')
    x = [extractfield(cell,'ave_fluor')];
end
end